function xout = oneDOU(x0,dt,ntMax)

%% Simulates a 1D Ornstein-Ulenbeck process. 
% Parameters
tauSlow = 1; % s

sigmax = 1; %nm

%% time loop

% initial condition
x = x0;

% Euler-Maruyama
for nt=1:ntMax
    
    x = x - 1/(tauSlow)*x*dt + (sigmax/(sqrt(tauSlow)))*sqrt(2*dt).*randn(size(x));
    
end % finished time loop

xout = x;
end